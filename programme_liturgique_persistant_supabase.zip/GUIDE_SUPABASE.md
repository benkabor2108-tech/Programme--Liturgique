# Programme liturgique — sauvegarde persistante Supabase

Cette version garde durablement les noms, les membres actifs/inactifs, l'historique et la rotation Lecture ↔ Monition/P.U., même après un redémarrage ou un redéploiement Streamlit.

## 1. Créer un projet Supabase

1. Ouvrez https://supabase.com et créez un compte ou connectez-vous.
2. Créez un nouveau projet, par exemple **programme-liturgique**.
3. Attendez que le projet soit prêt.

## 2. Créer la table

1. Dans le projet Supabase, ouvrez **SQL Editor**.
2. Créez une nouvelle requête.
3. Copiez tout le contenu du fichier `supabase_setup.sql`.
4. Appuyez sur **Run**.

La table `liturgie_state` sera créée avec la sécurité RLS activée. Les clés publiques n'ont aucun accès direct.

## 3. Récupérer les deux informations Supabase

Dans le tableau de bord Supabase :

- récupérez l'**URL du projet** ; elle ressemble à `https://xxxx.supabase.co` ;
- dans **Settings > API Keys**, créez ou copiez une **Secret key** (`sb_secret_...`). C'est la clé recommandée pour un backend. Une ancienne clé `service_role` fonctionne aussi, mais préférez une Secret key.

**Ne mettez jamais cette clé dans GitHub et ne l'envoyez jamais dans un message.**

## 4. Ajouter les secrets à Streamlit

Dans votre application Streamlit Community Cloud :

1. Ouvrez **Manage app / Gérer l'application**.
2. Ouvrez `⋮` puis **Settings**.
3. Ouvrez l'onglet **Secrets**.
4. Collez ce modèle en remplaçant uniquement les valeurs :

```toml
app_password = "CHOISISSEZ_UN_MOT_DE_PASSE"

[supabase]
url = "https://VOTRE-PROJET.supabase.co"
api_key = "sb_secret_VOTRE_CLE"
state_key = "programme-liturgique-principal"
```

5. Enregistrez les secrets et redémarrez l'application.

`app_password` protège l'interface si l'application Streamlit est publique. Utilisez un mot de passe différent de votre mot de passe GitHub ou Supabase.

## 5. Mettre à jour GitHub

Remplacez dans votre dépôt :

- `liturgie_app.py`
- `requirements.txt`

Gardez exactement ces noms et validez sur la branche `main`.

## 6. Premier démarrage

Au premier démarrage :

1. l'application vous demande le mot de passe défini dans les secrets ;
2. si aucune sauvegarde n'existe encore, elle crée automatiquement un état initial de 10 francophones et 8 mooréphones ;
3. saisissez les noms une fois dans **Membres** ;
4. ils sont immédiatement sauvegardés dans Supabase.

Ensuite, un redémarrage Streamlit recharge automatiquement les données depuis Supabase.

## 7. Vérification

Dans **Réglages > Sauvegarde persistante**, appuyez sur **Tester et resynchroniser maintenant**. L'application doit afficher que la connexion et la sauvegarde sont vérifiées.

Gardez aussi l'export JSON : il reste utile comme sauvegarde de secours indépendante.
