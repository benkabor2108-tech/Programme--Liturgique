-- Base persistante pour l'application Programme liturgique
-- À exécuter une seule fois dans Supabase > SQL Editor.

create table if not exists public.liturgie_state (
    app_key text primary key,
    state_json jsonb not null default '{}'::jsonb,
    updated_at timestamptz not null default now()
);

-- Les données ne sont pas accessibles aux clés publiques.
alter table public.liturgie_state enable row level security;
revoke all on table public.liturgie_state from anon, authenticated;
grant all on table public.liturgie_state to service_role;

comment on table public.liturgie_state is
'Sauvegarde persistante de l''état du programme liturgique Streamlit.';
